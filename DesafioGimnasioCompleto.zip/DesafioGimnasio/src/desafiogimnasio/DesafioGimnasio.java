/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package desafiogimnasio;

import Entidades.Cliente;
import Entidades.Rutina;
import Servicios.ServicioCliente;
import Servicios.ServicioRutina;
import java.util.ArrayList;
import java.util.Iterator;

public class DesafioGimnasio {

    public static void main(String[] args) {
        //Crear servicio
        ServicioCliente sc = new ServicioCliente();
        //Crear Arraylist de cliente
        ArrayList<Cliente> arrayCliente = new ArrayList<>();

        ServicioRutina sr = new ServicioRutina();
        ArrayList<Rutina> arrayRutina = new ArrayList<>();

        //Agrega un objeto al Arraylist
//        for (int i = 0; i < 2; i++){
//        arrayCliente.add(sc.crearCliente()); 
//        }
        arrayCliente.add(sc.crearCliente(100, "Juan", 40, 1.70, 70, "Musculación"));
        arrayCliente.add(sc.crearCliente(101, "Julio Cesar", 28, 1.80, 82, "Fitness"));
        arrayCliente.add(sc.crearCliente(102, "Lucas", 23, 1.67, 65, "Musculación"));
        arrayCliente.add(sc.crearCliente(103, "Mónica", 21, 1.60, 52, "Zumba"));
        arrayCliente.add(sc.crearCliente(104, "Camila", 23, 1.57, 55, "Rock & Roll"));
//        System.out.println("-----");
        sc.obtenerCliente(arrayCliente);
        
        arrayRutina.add(sr.crearRutina(1020, "Rutina levanta cola", 30, "Fácil", "Step"));
        arrayRutina.add(sr.crearRutina(1021, "Rutina levanta ánimo", 5, "SuperFácil", "Paintbrush"));
        arrayRutina.add(sr.crearRutina(1022, "Espalda", 25, "Jodido", "Remo"));
        arrayRutina.add(sr.crearRutina(1023, "Biceps", 50, "Jodido", "Press"));
        arrayRutina.add(sr.crearRutina(1024, "Pierna", 20, "Flaca", "De tero"));
        System.out.println("-----");
        sr.obtenerRutina(arrayRutina);
        
        sc.actualizarCliente(arrayCliente, 100, "Mauro", 35, 1.90, 75, "Mantener estado Fisico");
        System.out.println("-----");
        sc.obtenerCliente(arrayCliente);
        
        sr.actualizarRutina(arrayRutina, 1022, "Triceps", 13, "Medio", "Dale con tuti!");
        System.out.println("-----");
        sr.obtenerRutina(arrayRutina);
        
        sc.borrarCliente(arrayCliente);
        System.out.println("-----");
        sc.obtenerCliente(arrayCliente);

        sr.borrarRutina(arrayRutina);
        System.out.println("-----");
        sr.obtenerRutina(arrayRutina);

    }
}
