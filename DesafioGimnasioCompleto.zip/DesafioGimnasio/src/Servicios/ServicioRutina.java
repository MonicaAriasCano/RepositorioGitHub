package Servicios;

import Entidades.Rutina;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class ServicioRutina {

    private final Scanner leer = new Scanner(System.in).useDelimiter("\n");

    //Crear rutina
    public Rutina crearRutina() {
        Rutina r1 = new Rutina();
        System.out.println("Ingrese el ID del rutina: ");
        r1.setId(leer.nextInt());
        System.out.println("Ingrese el nombre de la rutina: ");
        r1.setNombre(leer.next());
        System.out.println("Ingrese la descripción de la rutina: ");
        r1.setDescripcion(leer.next());
        System.out.println("Ingresar la duración de la rutina: ");
        r1.setDuracion(leer.nextInt());
        System.out.println("Ingresar la dificultad de la rutina: ");
        r1.setNivelDificultad(leer.next());
        // Retorna r1 que es un objeto con todos los campos definidos
        return r1;
    }

    public void mostrarRutina(Rutina r1) {
        System.out.println("El id del rutina es: " + r1.getId());
        System.out.println("El nombre de la rutina es: " + r1.getNombre());
        System.out.println("La descripción de la rutina es: " + r1.getDescripcion());
        System.out.println("La duración de la rutina es: " + r1.getDuracion());
        System.out.println("La dificultad de la rutina es: " + r1.getNivelDificultad());
    }

    public void actualizarRutina(ArrayList<Rutina> listaRutinas, int id, String nombre, int duracion, String nivelDificultad, String descripcion) {

        for (Rutina rut : listaRutinas) {
            if (rut.getId() == id) {
                rut.setNombre(nombre);
                rut.setDuracion(duracion);
                rut.setNivelDificultad(nivelDificultad);
                rut.setDescripcion(descripcion);
                break;
            }
        }
    }

    public Rutina crearRutina(int id, String nombre, int duracion, String nivelDificultad, String descripcion) {
        return new Rutina (id, nombre, duracion, nivelDificultad, descripcion);
    }

    public void obtenerRutina(ArrayList<Rutina> listaRutina) {
        Iterator<Rutina> rutinaIterator = listaRutina.iterator();
        //Recorre directa/ el Array
        while (rutinaIterator.hasNext()) {
            //Extrae c/u de los objetos almacenados
            Rutina r = rutinaIterator.next();
            //Toma el objeto "r" y lo muestra mediante la función de servicio
            mostrarRutina(r);
            System.out.println("");
        }
    }

    public void borrarRutina(ArrayList<Rutina> listaRutinas) {
        System.out.println("Por favor, ingrese el ID de la rutina que quiere volar");
        int id = leer.nextInt();
        for (Rutina rut : listaRutinas) {
            if (rut.getId() == id) {
                listaRutinas.remove(rut);
                //usando .remove
                break;
            }
        }
    }

}
