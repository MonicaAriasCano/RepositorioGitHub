/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servicios;

import Entidades.Cliente;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

/**
 *
 * @author Familia
 */
public class ServicioCliente {

    private final Scanner leer = new Scanner(System.in).useDelimiter("\n");

    //Crear cliente
    public Cliente crearCliente() {
        Cliente cl = new Cliente();
        System.out.println("Ingrese el ID del cliente: ");
        cl.setId(leer.nextInt());
        System.out.println("Ingrese el nombre del cliente: ");
        cl.setNombre(leer.next());
        System.out.println("Ingrese la edad del cliente: ");
        cl.setEdad(leer.nextInt());
        System.out.println("Ingresar la altura del cliente: ");
        cl.setAltura(leer.nextDouble());
        System.out.println("Ingresar el peso del cliente: ");
        cl.setPeso(leer.nextDouble());
        System.out.println("Ingresar el objetivo del cliente: ");
        cl.setObjetivo(leer.next());
        // Retorna cl que es un objeto con todos los campos definidos
        return cl;
    }

    public void mostrarCliente(Cliente cl) {
        System.out.println("El id del cliente es: " + cl.getId());
        System.out.println("El nombre del cliente es: " + cl.getNombre());
        System.out.println("La edad del cliente es: " + cl.getEdad());
        System.out.println("La altura del cliente es: " + cl.getAltura());
        System.out.println("El peso del cliente es: " + cl.getPeso());
        System.out.println("El objetivo del cliente es: " + cl.getObjetivo());
    }

    public void actualizarCliente(ArrayList<Cliente> listaClientes, int id, String nombre, int edad, double altura, double peso, String objetivo) {

        for (Cliente cli : listaClientes) {
            if (cli.getId() == id) {
                cli.setNombre(nombre);
                cli.setEdad(edad);
                cli.setAltura(altura);
                cli.setPeso(peso);
                cli.setObjetivo(objetivo);
                break;
            }
        }
    }

    public Cliente crearCliente(int id, String nombre, int edad, double altura, double peso, String objetivo) {
        return new Cliente(id, nombre, edad, altura, peso, objetivo);
    }

    public void obtenerCliente(ArrayList<Cliente> listaClientes) {
        Iterator<Cliente> clienteIterator = listaClientes.iterator();
        //Recorre directa/ el Array
        while (clienteIterator.hasNext()) {
            //Extrae c/u de los objetos almacenados
            Cliente c = clienteIterator.next();
            //Toma el objeto "c" y lo muestra mediante la función de servicio
            mostrarCliente(c);
            System.out.println("");
        }
    }

    public void borrarCliente(ArrayList<Cliente> listaClientes) {
        System.out.println("Por favor, ingrese el ID del que quiere volar");
        int id = leer.nextInt();
        for (Cliente cli : listaClientes) {
            if (cli.getId() == id) {
                listaClientes.remove(cli);
                //usando .remove
                break;
            }
        }
    }

}
