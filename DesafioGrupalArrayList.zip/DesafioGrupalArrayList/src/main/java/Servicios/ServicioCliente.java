package Servicios;

import Entidad.Cliente;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ServicioCliente {

    Cliente c1 = new Cliente();
    Scanner leer = new Scanner(System.in).useDelimiter("\n");

//ArrayList
    List<Cliente> listaClientes = new ArrayList<Cliente>();

//registrarCliente: lo registra en el sistema.
    public void registrarCliente(ArrayList<Cliente> listaClientes) {
        System.out.println("Ingrese el id del cliente: ");
        c1.setId(leer.nextInt());
        System.out.println("Ingrese el nombre del cliente: ");
        c1.setNombre(leer.next());
        System.out.println("Ingrese la edad del cliente: ");
        c1.setEdad(leer.nextInt());
        System.out.println("Ingrese la altura del cliente: ");
        c1.setAltura(leer.nextDouble());
        System.out.println("Ingrese el peso del cliente: ");
        c1.setPeso(leer.nextDouble());
        System.out.println("Ingrese los objetivos del cliente: ");
        c1.setObjetivo(leer.nextLine());

        listaClientes.add(c1);

        //todos los "leer" se cargan en c1 creando un nuevo indice por cada cliente agregado
    }

//obtenerClientes(): devuelve una lista con todos los clientes registrados en el sistema.
    public void obtenerCliente(ArrayList<Cliente> listaClientes) {

        //cli es la variable que creamos para llamar a nuestra ArrayList
        for (Cliente cli : listaClientes) {
            System.out.println("Id: " + cli.getId() + " Nombre: " + cli.getNombre() + " Objetivo: " + cli.getObjetivo());
        }

        //imprimimos en pantalla toda la lista con los paramentro indicados en el sout
    }

    /*
actualizarCliente(int id, String nombre, int edad, double altura, double peso, String objetivo): recibe el identificador
de un cliente existente y los nuevos datos del cliente, y actualiza la información correspondiente en el sistema.
     */
    public void actualizarCliente(ArrayList<Cliente> listaClientes, int id, String nombre, int edad, double altura, double peso, String objetivo) {

        for (Cliente cli : listaClientes) {
            if (cli.getId() == id) {
                cli.setNombre(nombre);
                cli.setEdad(edad);
                cli.setAltura(altura);
                cli.setPeso(peso);
                cli.setObjetivo(objetivo);
            }
        }
    }
    
//eliminarCliente(int id): recibe el identificador de un cliente existente y lo elimina del sistema.
    public void eliminarCliente(ArrayList<Cliente> listaClientes, int id) {

        for (Cliente cli : listaClientes) {
            if (cli.getId() == id) {
                listaClientes.remove(cli);
                //usando .remove eliminamos el indice donde esta el cliente completo, lo buscamos por la id
            }
        }
    }
}
