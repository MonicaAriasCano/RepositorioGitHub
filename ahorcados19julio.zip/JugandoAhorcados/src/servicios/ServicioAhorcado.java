/*
 */
package servicios;

import entidades.Ahorcado;
import java.util.Scanner;

/**
 *
 * @author Alejandro
 */
public class ServicioAhorcado {

    Scanner leer = new Scanner(System.in).useDelimiter("\n");
    Ahorcado nuevo = new Ahorcado();
    int intentos = 0;
    String[] comodin;

//     Metodo crearJuego(): le pide la palabra al usuario y cantidad de jugadas máxima.
//Con la palabra del usuario, pone la longitud de la palabra, como la longitud del
//vector. Después ingresa la palabra en el vector, letra por letra, quedando cada letra
//de la palabra en un índice del vector. Y también, guarda en cantidad de jugadas
//máximas, el valor que ingresó el usuario y encontradas en 0.
    public void crearJuego() {
        System.out.println("Ingrese la palabra secreta para iniciar el juego");
        String palabraSecreta = leer.next().toUpperCase();
        String[] cadena = new String[palabraSecreta.length()];
        for (int i = 0; i < palabraSecreta.length(); i++) {
            cadena[i] = palabraSecreta.substring(i, i + 1);

        }
        nuevo.setPalabra(cadena);
        System.out.println("Ingrese la cantidad de jugadas máximas para esta palabra");
        nuevo.setJugadasMaximas(leer.nextInt());
        nuevo.setLetrasEncontradas(0);
        comodin = nuevo.getPalabra();

    }

//     Método longitud(): muestra la longitud de la palabra que se debe encontrar. Nota:
//buscar como se usa el vector.length.
    public int longitud() {
        int longitud = nuevo.getPalabra().length;

        return longitud;
    }

//     Método buscar(letra): este método recibe una letra dada por el usuario y busca si la
//letra ingresada es parte de la palabra o no. También informará si la letra estaba o no.
    public void buscar(String letra) {

        boolean flag = false;
        for (int i = 0; i < nuevo.getPalabra().length; i++) {
            if (letra.equalsIgnoreCase(comodin[i])) {
                nuevo.setLetrasEncontradas(nuevo.getLetrasEncontradas() + 1);
                flag = true;

            }
        }
        if (flag) {
            System.out.println("¡Muy bien! La letra pertenece a la palabra secreta!!");
            
//           for (int i = 0; i < nuevo.getPalabra().length; i++) {
//            if(letra.equalsIgnoreCase(comodin[i])){
//               muestra[i]=letra;
//            }

        } else {
            System.out.println("Lamentablemente la letra (" + letra + ") no pertenece a la palabra secreta");
            intentos = intentos + 1;

        }

    }

//     Método encontradas(letra): que reciba una letra ingresada por el usuario y muestre
//cuantas letras han sido encontradas y cuantas le faltan. Este método además deberá
//devolver true si la letra estaba y false si la letra no estaba, ya que, cada vez que se
//busque una letra que no esté, se le restará uno a sus oportunidades.
    public boolean encontradas(String letra) {
        boolean flag = false;
        int total = nuevo.getPalabra().length;

        System.out.println("Cantidad de letras encontradas: " + nuevo.getLetrasEncontradas());
        System.out.println("Cantidad de letras aún sin encontrar: " + (total - nuevo.getLetrasEncontradas()));
        for (int i = 0; i < nuevo.getPalabra().length; i++) {
            if (letra.equalsIgnoreCase(comodin[i])) {
                comodin[i] = "*";
                flag = true;
            }
        }

        System.out.println(flag);
        return flag;
    }

// Método intentos(): para mostrar cuantas oportunidades le queda al jugador.
    public void intentos() {

        System.out.println("Quedan " + (nuevo.getJugadasMaximas() - intentos) + " intentos");
    }

//     Método juego(): el método juego se encargará de llamar todos los métodos
//previamente mencionados e informará cuando el usuario descubra toda la palabra o
//se quede sin intentos. Este método se llamará en el main.
    public void juego() {
        crearJuego();
        longitud();
        String[] muestra = new String[nuevo.getPalabra().length];

        for (int i = 0; i < nuevo.getPalabra().length; i++) {
            muestra[i] = " _ ";
        }

        do {
            System.out.println("Encuentre la palabra escondida aquí..");

            for (int i = 0; i < nuevo.getPalabra().length; i++) {
                System.out.print(muestra[i]);
            }

            System.out.println("\n Ingrese una Letra para buscar");
            String letra = leer.next().toUpperCase();
            for (int i = 0; i < nuevo.getPalabra().length; i++) {
                if (letra.equalsIgnoreCase(nuevo.getPalabra()[i])) {
                    muestra[i] = letra;
                }
            }
            buscar(letra);
            encontradas(letra);

            intentos();

        } while (intentos != nuevo.getJugadasMaximas() && nuevo.getPalabra().length != nuevo.getLetrasEncontradas());

        if (intentos == nuevo.getJugadasMaximas()) {
            System.out.println("Usted ha sido ahorcado!!");
        } else if (nuevo.getPalabra().length == nuevo.getLetrasEncontradas()) {
            System.out.println("felicidades!!!");
        }
        System.out.println("LETRAS ENCONTRADAS");
        for (int i = 0; i < nuevo.getPalabra().length; i++) {
            System.out.print(muestra[i]);

        }
        
        System.out.println("\n PALABRA ESCONDIDA");

        for (int i = 0; i < nuevo.getPalabra().length; i++) {
            System.out.print(nuevo.getPalabra()[i]);
            System.out.print(comodin[i]);

        }

    }
}
