/*

 */
package jugandoahorcados;


import servicios.ServicioAhorcado;

/**
 *
 * @author Alejandro
 */
public class JugandoAhorcados {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        ServicioAhorcado juego = new ServicioAhorcado();
        
        juego.juego();
        
    }
    
}
