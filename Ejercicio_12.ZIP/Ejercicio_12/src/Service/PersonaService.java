/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import Entidad.Persona;
import java.util.Date;
import java.util.Scanner;

/**
 *
 * @author Usuario
 */
public class PersonaService {
    private final  Scanner read = new Scanner(System.in).useDelimiter("\n");
    
    public Persona crearPersona(){
        Persona p = new Persona();
        Date birth = new Date();
        System.out.print("Ingrese el nombre de la persona: ");
        p.setNombre(read.next());
        System.out.println("Ingrese la fecha de nacimiento dd/mm/yyyy:");
        System.out.print("Día: ");
        birth.setDate(read.nextInt());
        System.out.print("Mes: ");
        birth.setMonth(read.nextInt()-1);
        System.out.print("Año: ");
        birth.setYear(read.nextInt()-1900);
        p.setBirth(birth);
        
        return p;
    }
    
    public int calcularEdad(Persona p){
        Date fActual = new Date();
        return fActual.getYear()-p.getBirth().getYear();
    }
    
    public void esMenorQue(Persona p, int edad){
        Date fActual = new Date();
        if(p.menorQue(fActual.getYear()-edad)){
            System.out.println("La persona efectivamente es menor de " + edad);
            System.out.println("Porque tiene "+(calcularEdad(p)));
        }else{
            System.out.println("La persona efectivamente es mayor de " + edad);
            System.out.println("Porque tiene "+(calcularEdad(p)));
        }
    }
    
    public void mostrarP(Persona p){
        System.out.println(p);
    }
}
